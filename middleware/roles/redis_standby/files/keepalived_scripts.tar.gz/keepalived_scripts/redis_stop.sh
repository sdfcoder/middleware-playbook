#!/bin/bash 
LOGFILE=/apps/logs/redis_6379/keepalived-redis-state.log
echo "[stop]" >> $LOGFILE 
date >> $LOGFILE
