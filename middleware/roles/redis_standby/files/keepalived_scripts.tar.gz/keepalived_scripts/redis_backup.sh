#!/bin/bash 
REDISCLI="/apps/svr/redis_6379/src/redis-admin"
LOGFILE="/apps/logs/redis_6379/keepalived-redis-state.log"
echo "[backup]" >> $LOGFILE 
date >> $LOGFILE 
echo "Run SLAVEOF cmd ..." >> $LOGFILE 
$REDISCLI SLAVEOF $2 $3 >> $LOGFILE 2>&1 
# echo "Being slave...." >> $LOGFILE 2>&1 
sleep 15 #delay 15 s wait data sync exchange role
